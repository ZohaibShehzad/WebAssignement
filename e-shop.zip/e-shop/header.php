 <header>
        <!-- top Header -->
        <div id="top-header">
            <div class="container">
                

            </div>
        </div>
        <!-- /top Header -->
        <!-- header -->
        <div id="header">
            <div class="container">
                <div class="pull-left">
                    <!-- Logo -->
                    <div class="header-logo">
                        <a class="logo" href="#">
                            <img src="./img/logo.jpg"  alt="" height="100" width="20" >
                        </a>
                    </div>
                    <!-- /Logo -->
                </div>
                <div class="pull-right">
                    <ul class="header-btns">
                        <!-- Mobile nav toggle-->
                        <li class="nav-toggle">
                            <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                        </li>
                        <!-- / Mobile nav toggle -->
                    </ul>
                </div>
            </div>
            <!-- header -->
        </div>
        <!-- container -->
    </header>
    <!-- /HEADER -->
    <!-- NAVIGATION -->
    <div id="navigation">
        <!-- container -->
        <div class="container">
            <div id="responsive-nav">
                <!-- category nav -->
                <div class="category-nav show-on-click" >
                    <span class="category-header">Categories <i class="fa fa-list"></i></span>
                    <ul class="category-list">

                        <li><a href="#">Laptops</a></li>
                        <li><a href="#">Mobiles</a></li>
                        <li><a href="#">Bags</a></li>

                        <li><a href="#">View All</a></li>
                    </ul>
                </div>
                <!-- /category nav -->
                <!-- menu nav -->
                <div class="menu-nav">
                    <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                    <ul class="menu-list">
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Laptops</a></li>
                        <li><a href="#">Mobiles</a></li>
                        <li><a href="#">Bags</a></li>
                    </ul>
                </div>
                <!-- menu nav -->
            </div>
        </div>
        <!-- /container -->
    </div>
    <!-- /NAVIGATION -->
    <!-- BREADCRUMB -->
    <div id="breadcrumb">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li><a href="#">Products</a></li>
                <li><a href="#">Category</a></li>
                <li class="active">Laptop</li>
            </ul>
        </div>
    </div>