-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2019 at 05:46 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(3) NOT NULL,
  `Name` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `Brand` varchar(20) COLLATE utf8mb4_bin NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Image` blob,
  `detail` text COLLATE utf8mb4_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `Name`, `Brand`, `Quantity`, `Image`, `detail`) VALUES
(1, 'Hp111', 'HP', 15, NULL, 'CPU: 2.5GHz Intel Core i7-6500U (dual-core, 4MB cache, up to 3.1GHz with Turbo Boost) Graphics: Intel HD Graphics 520. RAM: 8GB LPDDR3 SDRAM (1,866MHz) Screen: 13.3-inch, 1,920 x 1,080 FHD IPS UWVA BrightView Corning Gorilla Glass WLED-backlit display.'),
(2, 'Asus104', 'Asus', 20, NULL, 'ASUS ROG GL752VW-DH71 17.3-inch Gaming Laptop (Intel i7 2.6GHz, 16GB DDR4 RAM, 1TB HDD, GTX960M 2GB Graphic Card, Windows 10) GL752VW is powered by a 6th generation Intel Core i7 quad-core processor, with a discrete NVIDIA GTX 960 graphics card with Full DirectX 12 support. ... 16GB RAM; 1TB 7200RPM Storage.'),
(3, 'L45-Ideapad', 'Lenevo', 25, NULL, 'The Lenovo Ideapad 110 is influenced by an Intel Core i3-6100U processor with 2.3 GHz speed and Intel HD 520 Graphics, providing you lots of processing capability for internet surfing and streaming. This Lenovo i5 has a 4GB of installed RAM, which is sufficient for the completion of everyday tasks.'),
(4, 'I5', 'Dell', 10, NULL, 'Starting at about 2.54 cm (1\") thin, the Inspiron 14 is sleek and portable. And its modern design makes it as stylish as it is mobile.\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
