<?php
/**
 * Created by PhpStorm.
 * User: Zaheer Sani
 * Date: 16/04/2019
 * Time: 2:17 PM
 */

define('DBHOST', 'localhost');
define('DBNAME', 'website');
define('DBUSER', 'root');
define('DBPASSWORD', '');

?>